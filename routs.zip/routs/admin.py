from django.contrib import admin
from .models import Town ,Hotels


admin.site.register(Town)
admin.site.register(Hotels)

# Register your models here.
