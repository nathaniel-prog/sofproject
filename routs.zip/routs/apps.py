from django.apps import AppConfig


class RoutsConfig(AppConfig):
    name = 'routs'
