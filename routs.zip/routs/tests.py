from django.test import TestCase

# Create your tests here.


def query(request):
    print(request.GET)